source('../../libraries.R')

#a <- read.csv('performance_with_good_bad.csv',stringsAsFactors = F)

b <- a %>% filter(tag_type %in% c('good','bad'),!is.na(ordinal), impressions>100) %>%
  mutate(floor_price_bin=round(floor_price*2.5)/2.5,
         ordinal=as.factor(ordinal),
         tag_type=as.factor(tag_type)) %>%
  group_by(placement_id, tag_type, ordinal, floor_price_bin) %>%
  summarise(impressions=sum(impressions), served=sum(served), income=sum(income)) %>%
  mutate(fill=served/impressions, ecpm=1000*income/served)

c <- b %>% dcast(placement_id + ordinal + floor_price_bin ~ tag_type,value.var="fill") %>%
  filter(!is.na(bad),!is.na(good)) %>%
  mutate(win=ifelse(good>bad,1,0))

p1 <- ggplot(b) + geom_point(aes(x=placement_id,y=fill,colour=tag_type)) + facet_grid(floor_price_bin~ordinal) #+coord_cartesian(ylim=c(0,0.2))
p2 <- ggplot(b) + geom_point(aes(x=placement_id,y=ecpm,colour=tag_type)) + facet_grid(floor_price_bin~ordinal)
#print(p2)